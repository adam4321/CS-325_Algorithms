Author:       Adam Wright 
Date:         10/16/2019 
Description:  README for Homework 3 program


-To compile the program on Linux, just unzip the folder and then type "make" into the command line from within the directory. The makefile will compile the program into an  executable.

-To run the program, just type the name into the commannd line from within the directory that it is in. The program is:

-shopping
