Author:       Adam Wright\
Date:         11/26/2019 \
Description:  Implementation for the bin packing problem

-To compile the program on Linux, just unzip the folder and then type "make" into the command line from within the directory. The makefile will compile the program into an  executable.

-To run the program, just type the name into the commannd line from within the directory that it is in. The program is:

-binpack
