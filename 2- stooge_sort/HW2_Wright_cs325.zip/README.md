
Author:         Adam Wright
Date:           10/10/2019
Description:    README for Homework 2 programs


-To compile the programs on Linux, just unzip the folder and then type "make" into
the command line from within the directory. The makefile will compile the two
programs into the 2 final executables.

-To run the programs, just type the name into the commannd line from within
the directory that they are in. The 2 programs are:

- stoogesort
- stoogeTime