
Author:         Adam Wright
Date:           10/4/2019
Description:    README for Homework 1 programs


-To compile  the programs, just unzip the folder and then type "make" into
the command line from within the directory. The makefile will compile all
of the programs into the 4 executables.

-To run the programs, just type the name into the commannd line from within
the directory that they are in. The 4 programs are:

- insertsort
- mergesort
- insertTime
- mergeTime